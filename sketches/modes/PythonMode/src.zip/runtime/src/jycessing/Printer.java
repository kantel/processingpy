package jycessing;

public interface Printer {
  void print(Object o);

  void flush();
}
