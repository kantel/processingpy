a = PMatrix3D()
a.print()
exit()
